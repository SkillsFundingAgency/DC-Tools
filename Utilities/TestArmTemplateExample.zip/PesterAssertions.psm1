﻿Function BeValidJsonFile {
<#
.SYNOPSIS
Tests whether a file is a valid json file
#>
    [CmdletBinding()]
    Param(
        $ActualValue,
        [switch]$Negate
    )

    
     [bool]$Pass = $false
try{
    $json = (get-content $ActualValue | ConvertFrom-Json )
    $Pass = $true
 }
 catch{
     $Pass = $false
 
 }

    If ( $Negate ) { $Pass = -not($Pass) }

    If ( -not($Pass) ) {
        If ( $Negate ) {
            $FailureMessage = 'Expected: file {{{0}}} to contain invalid json, but it was valid.' -f $ActualValue
        }
        Else {
            $FailureMessage = 'Expected: file {{{0}}} to contain valid json, but it was invalid.' -f $ActualValue
        }
    }

    $ObjProperties = @{
        Succeeded      = $Pass
        FailureMessage = $FailureMessage
    }
    return New-Object PSObject -Property $ObjProperties
}

Function HasExpectedResources {
<#
.SYNOPSIS
Tests whether an arm template has expected resources
#>
    [CmdletBinding()]
    Param(
        $ActualValue,
        $ExpectedResources,
        [switch]$Negate
    )
     $mismatchedResource = ""
     [bool]$Pass = $false
     $expectedResourceList = $ExpectedResources.Split(',')

try{
    $resources = (get-content $ActualValue | ConvertFrom-Json ).Resources.type 
    foreach($expRes in $expectedResourceList){
    foreach($res in $resources){
    if($expRes -eq $res){
        $Pass = $true
        break
       }
      }
      if($Pass -eq $false){
       $mismatchedResource = $expRes
      break
      }
    }

      
        
 }
 catch{
     $Pass = $false
 
 }

    If ( $Negate ) { $Pass = -not($Pass) }

    If ( -not($Pass) ) {
        If ( $Negate ) {
            $FailureMessage = 'Expected: resources {{{0}}} should be in file, all expected resources exists.' -f $mismatchedResource
        }
        Else {
            $FailureMessage = 'Expected: resources {{{0}}} should be in file, expected resource(s) does not exists.' -f $mismatchedResource
        }
    }

    $ObjProperties = @{
        Succeeded      = $Pass
        FailureMessage = $FailureMessage
    }
    return New-Object PSObject -Property $ObjProperties
}

Function HasAllParametersDefined {
<#
.SYNOPSIS
Tests whether an arm template has expected resources
#>
    [CmdletBinding()]
    Param(
        $ActualValue, #template with path
        [switch]$Negate
    )
     $mismatchedParam = ""
     [bool]$Pass = $true
     $regExParams = "parameters\('(?<Name>[^']+'\))"
     $parameters = (get-content $ActualValue | ConvertFrom-Json ).Parameters
     

try{
    
    $templateText = get-content $ActualValue 
    $objects = $templateText | select-string -pattern $regExParams -AllMatches | Foreach {$_.Matches} |Get-Unique 
    #$templateText | select-string -pattern $regExParams -AllMatches | Foreach {$_.Matches} |Get-Unique |foreach-object{
    foreach($obj in $objects){
        $parm = $obj.Value.Replace("parameters('", "").Replace("')", "")
        if($parameters.PSObject.Properties.Match($parm).Count -eq 0){
                $Pass = $false
                $mismatchedParam = $parm
               break
            }
   }
   
 }
 catch{
     $Pass = $false
 
 }

    If ( $Negate ) { $Pass = -not($Pass) }
    
    If ( -not($Pass) ) {
        If ( $Negate ) {
            $FailureMessage = 'Expected: parameter {{{0}}} should defined in the parameter section, all expected parameters exists.' -f $mismatchedParam
        }
        Else {
            $FailureMessage = 'Expected: parameter {{{0}}} should defined in the parameter section, expected parameters does not exists.' -f $mismatchedParam
        }
    }

    $ObjProperties = @{
        Succeeded      = $Pass
        FailureMessage = $FailureMessage
    }
    return New-Object PSObject -Property $ObjProperties
}



