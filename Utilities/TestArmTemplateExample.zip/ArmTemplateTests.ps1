﻿param($TemplateFile, $here, $expectedResources)
$curPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Import-Module "$curPath\PesterAssertions.psm1" -Force

Add-AssertionOperator -Name BeValidJsonFile -Test $Function:BeValidJsonFile
Add-AssertionOperator -Name HasExpectedResources -Test $Function:HasExpectedResources
Add-AssertionOperator -Name HasAllParametersDefined -Test $Function:HasAllParametersDefined
$sut =   $TemplateFile #$sut.Replace('ps1', 'json')
write-host "here is $here"
Describe "ARM Template $TemplateFile exists" {
    It "Has ARM Template file" {
         "$here\$sut" | Should Exist
    }
   <#  It "Has Parameter file" {
     $parameterFile = $TemplateFile.Replace('.json', '.parameters.json')
       "$here\$parameterFile" | Should Exist
    }
    #>
     It "Template has valid json elements" {
        "$here\$TemplateFile" | Should  -BeValidJsonFile 
    }
     It "Template should have all the parameters defined" {
        
        "$here\$TemplateFile" | Should  -HasAllParametersDefined 
    }
    It "Template Has expected resources in the template" {
        
        "$here\$TemplateFile" | Should  -HasExpectedResources $expectedResources
    }
}
<#
$curPath = Split-Path -Parent $MyInvocation.MyCommand.Path

Invoke-Pester -Script @{ Path="$curPath\armtemplatetests.ps1"; Parameters = @{TemplateFile = 'dcservicebus.json'; here=$curPath; expectedresources='Microsoft.ServiceBus/Namespaces, Microsoft.ServiceBus/namespaces/queues, Microsoft.ServiceBus/namespaces/topics, Microsoft.ServiceBus/namespaces/topics/subscriptions, Microsoft.ServiceBus/namespaces/topics/subscriptions/rules, Microsoft.ServiceBus/namespaces/topics/subscriptions, Microsoft.ServiceBus/namespaces/topics/subscriptions/rules, Microsoft.ServiceBus/namespaces/topics/subscriptions, Microsoft.ServiceBus/namespaces/topics/subscriptions/rules, Microsoft.ServiceBus/namespaces/AuthorizationRules'}}

#>