﻿<#
$curPath = Split-Path -Parent $MyInvocation.MyCommand.Path

Invoke-Pester -Script @{ Path="$curPath\armtemplatetests.ps1"; Parameters = @{TemplateFile = 'dcservicebus.json'; here=$curPath; expectedresources='Microsoft.ServiceBus/Namespaces, Microsoft.ServiceBus/namespaces/queues, Microsoft.ServiceBus/namespaces/topics, Microsoft.ServiceBus/namespaces/topics/subscriptions, Microsoft.ServiceBus/namespaces/topics/subscriptions/rules, Microsoft.ServiceBus/namespaces/topics/subscriptions, Microsoft.ServiceBus/namespaces/topics/subscriptions/rules, Microsoft.ServiceBus/namespaces/topics/subscriptions, Microsoft.ServiceBus/namespaces/topics/subscriptions/rules, Microsoft.ServiceBus/namespaces/AuthorizationRules'}}

#>